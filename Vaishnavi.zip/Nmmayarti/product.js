let currentIndex = 0;
const slides = document.querySelectorAll(".slides");

function showSlides() {
    slides.forEach((slide, index) => {
        slide.classList.remove("active");
        if (index === currentIndex) {
            slide.classList.add("active");
        }
    });

    currentIndex = (currentIndex + 1) % slides.length;
}

setInterval(showSlides, 2000); // Change image every 2 seconds

// Initially display the first slide
showSlides();
